<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">

</head>
<body>
<?php include('header.php'); ?>

<div class="container login">
	<form action="verify.php" method="post">
		<div class="col-md-4 col-md-offset-4 text-center form">
		<h2>Login</h2>
		<br>
			<p><select name="logintype" required>
				<option>Login Type</option>
				<option value="Doctor">Doctor</option>
				<option value="Patient">Patient</option>
				<option value="Admin">Admin</option>
			</select></p>
			<p><input type="text" name="username" placeholder="Enter User Name" required></p>
			<p><input type="password" name="password" placeholder="Enter Password" required></p>
			<p><input type="submit" value="LOGIN" class="button"></p>
			<p><a href="register.php" class="button">Register</a></p>
			<p><a href="#" >Forgot Password</a></p>
			<?php
				if(isset($_GET['error'])){
					?>
					<p class="text-danger">Incorrect User Name Or Password</p>
					<?php
				}
			?>
		</div>
	</form>
</div>


<?php include('footer.php'); ?>
</body>
</html>