<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Contact Us Page</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

	<?php include('header.php'); ?>
<div class="container about">
	<h2 class="text-center text-primary">Contact Us</h2>
		<hr>
		<div class="col-md-7">
			<h3>Address:</h3>
			<p><b>Address Line 1 : </b> put address</p>
			<p><b>Address Line 2 : </b> put address</p>
			<hr>
			<p><b>Email : </b> put email</p>
			<hr>
			<p><b>Zip Code : </b> put zipcode</p>
			<hr>
			<p><b>Phone: </b> put phone no</p>
			<hr>	
			<p><b>Office  Hours : Monday to friday 08:30 am - 04:30 pm</b></p>
		</div>

		<div class="col-md-5">
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d20319565.46687872!2d-122.61972023398859!3d55.24357392213645!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4b0d03d337cc6ad9%3A0x9968b72aa2438fa5!2sCanada!5e0!3m2!1sen!2sin!4v1636885596658!5m2!1sen!2sin" width="100%" height="400" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
			
		</div>
	
</div>




<?php include('footer.php'); ?>
</body>
</html>