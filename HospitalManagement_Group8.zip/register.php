<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Register Page</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

<?php include('header.php'); ?>
<div class="container about">
	<form action="registeruser.php" method="post">
		<div class="col-md-4 col-md-offset-4 text-center form">
			<h2>Registration</h2>
			<hr>
			<p><select name="logintype" required>
				<option>Login Type</option>
				<option value="Doctor">Doctor</option>
				<option value="Patient">Patient</option>
			</select></p>
			<p><input type="text" name="fname" placeholder="Enter First Name" required pattern="[a-z, A-Z]{3,}" title="Enter a valid name"></p>
			<p><input type="text" name="lname" placeholder="Enter Last Name" required pattern="[a-z, A-Z]{3,}" title="Enter a valid name"></p>

			<p><input type="text" name="mob" placeholder="Enter Mobile No." required pattern="[0-9]{10}" title="Enter a valid Contact No."></p>

			<p><input type="email" name="email" placeholder="Enter Email ID" required></p>
			<p><input type="text" name="username" placeholder="Enter User Name" required></p>
			<p><input type="password" name="password" placeholder="Enter Password" required></p>
			<p><input type="password" name="Confpassword" placeholder="Confirm Password" required></p>
			
			<p><input type="submit" value="REGISTER" class="button"></p>
			<p><a href="login.php" class="button">Back To Login</a></p>

			<?php
				if(isset($_GET['error'])){
					?>
					<p class="text-danger">Incorrect User Name Or Password</p>
					<?php
				}
			?>
		</div>
	</form>
</div>


<?php include('footer.php'); ?>
</body>
</html>