<?php
session_start();
?>
<html lang="en">

<head>
   <title>Doctors Appointment Page</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">


</head>

<body>
    <?php include('header.php'); ?>

    <main>
	<br>
	<br>
	<h2  class="text-center text-primary">My Appointment details</h2>
	<br>
	<p class="text-right"><input id="myInput" type="text" placeholder="Search.."></p>
		<?php

require('mysqli_oop_connect.php');

$q = "SELECT Doctor_Name,Slot_No,Appointment_Date,pa.F_Name,pa.L_Name from appointment ap JOIN doctor doc ON ap.Doctor_ID = doc.Doctor_ID JOIN patient pa ON pa.Patient_ID = ap.Patient_ID where doc.Doctor_ID='".$_SESSION['userid']."'";


$r = $mysqli->query($q);

$rowCount = $r->num_rows;
if ($rowCount >= 1) {
    echo '<table style = "border: 1px solid black;text-align: center;background-color: #f2f2f2;">
        <thead>
        <tr>
        <th style = "border: 1px solid black;color:black">Doctor Name</th>
        <th style = "border: 1px solid black;color:black">Patient Name</th>
        <th style = "border: 1px solid black;color:black">Slot Number</th>
        <th style = "border: 1px solid black;color:black">Appointment Date</th>
        </tr>
        </thead>
        <tbody id="myTable">';
    
    while ($row = $r->fetch_object()) {
		
        echo '<tr>
              <td style = "border: 1px solid black">' . $row->Doctor_Name . '</td>
              <td style = "border: 1px solid black">' . $row->F_Name . '</td>
              <td style = "border: 1px solid black">' . $row->Slot_No . '</td>
              <td style = "border: 1px solid black">' . $row->Appointment_Date . '</td>
              </tr>';
    }

    echo '</tbody>
          </table>';

} else {

    echo '<h3>There are currently no appointments</h3>';

}

$mysqli->close();
?>


    </main>

<br>
<br>
<br>
<br>
    <?php include('footer.php'); ?>

</body>

</html>


