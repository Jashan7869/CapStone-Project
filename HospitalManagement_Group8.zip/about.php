<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>About Us Page</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

	<?php include('header.php'); ?>
<div class="container about">
	<h2 class="text-center text-primary">About Us</h2>
		<hr>

		<div class="col-md-4">
			<img src="images/logo.jpg" class="img-responsive">
		</div>
		<div class="col-md-7">
			
			<h3>About US</h3>

			<p>Our mission is to care for our patients and their families when it matters most.</p>

			<p>Our vision is to invent the future of health care.</p>

			<p>Our values are: excellence, collaboration, accountability, respect and engagement.</p>

			<p>From our beginnings as a hospital for Canadian veterans, Sunnybrook has flourished into a fully affiliated teaching hospital of the University of Toronto, evolving to meet the needs of our growing community. </p>

			<p>Today, with 1.3 million patient visits each year, Sunnybrook has established itself across three campuses and is home to Canada's largest trauma centre. </p>

			<p>Our groundbreaking research changes the way patients are treated around the world. Our over 200 scientists and clinician-scientists conduct more than $100 million of breakthrough research each year. Tomorrow, we will discover ways to treat the untreatable.</p>
		</div>

		
	
</div>




<?php include('footer.php'); ?>
</body>
</html>