<?php
session_start();
if(!isset($_SESSION['userid']))
{
   header('location:login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Appointment List</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

	<?php include('header.php'); ?>
<div class="container-fluid about">
	<h2 class="text-center text-primary">Book Appointment Page</h2>
   <hr>
   <div class="col-md-2">
      <p><a href="myappointments.php" class="btn btn-primary btn-block commandStyling">My Appointments</a></p>
      <p><a href="book.php" class="btn btn-primary btn-block commandStyling">Book Appointment</a></p>

      
   </div>
   <div class="col-md-10">
      <?php
         $conn = mysqli_connect('localhost','root','','hospital');
      ?>
        <p class="text-danger">
          <?php if(isset($_GET['error']))
          {
            echo "Slot Not Available";
          } ?>
        </p>
		
      <form action="bookappointment.php" method="post" style=" margin-right: 18%;">
	  <div class="col-md-4 col-md-offset-4 text-center form">
        <p><select name="docid">
           <?php
              $cmd = "select Doctor_ID, Doctor_Name from doctor";
              $res = mysqli_query($conn, $cmd);
              while($row= mysqli_fetch_array($res))
              {
           ?>
            <option value="<?php echo $row['Doctor_ID']; ?>"><?php echo $row['Doctor_Name']; ?></option>
           <?php
            }
            ?>

        </select></p>


        <p><select name="slot">
           <option value="10:00 AM">10:00 AM</option>
           <option value="11:00 AM">11:00 AM</option>
           <option value="12:00 PM">12:00 PM</option>
           <option value="01:00 PM">01:00 PM</option>
           <option value="02:00 PM">02:00 PM</option>
           <option value="03:00 PM">03:00 PM</option>
		   <option value="04:00 PM">04:00 PM</option>
		   <option value="05:00 PM">05:00 PM</option>
        </select></p>

        <p><input type="date" name="date"></p>

       <p><input type="submit" class="btn btn-primary commandStyling" value="Book Appointment"></p>
     </div>
	 </form>
	</div>
</div>




<?php include('footer.php'); ?>
</body>
</html>