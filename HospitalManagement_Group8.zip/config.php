<?php
	require_once "stripe-php-master/init.php";
	
	$stripedetails = array(
		"publishabelKey"=>"pk_test_51K1XfGHBVv0ZWAOhK9PRAPpyYg4RHourPSLBRnCaYFFdripc1tK3F1HAzvBMbSbat6PCwWRYY1tUHSRcjGoFapi900DDK1ihZd",
		"secretKey"=>"sk_test_51K1XfGHBVv0ZWAOhdNJ1ochmanPZ5El2NPVnEdMSnWZWrFR18yZxc2GofQ0BI1SPw4KOfq5ln9S106QJhktHbgJO00xntMINVP",
	);
	\Stripe\Stripe::setApiKey($stripedetails["secretKey"]);
?>