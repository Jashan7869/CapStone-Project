 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<nav class="navbar navbar-default">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
		         <i class="fa fa-bars fa-lg" style="color:#fff;"></i> 
		      </button>
				<a href="#" >
					<img src="images/logo.jpg" class="logo">
				</a>
			</div>

			<div class="collapse navbar-collapse" id="myNavbar">
			<ul class="nav navbar-nav navbar-right">
				<li><a href="index.php">Home</a></li>
				<li><a href="service.php">Services</a></li>
				<li><a href="contact.php">Contact Us</a></li>
				<li><a href="about.php">About Us</a></li>
				  <?php
               if(!isset($_SESSION['userid']))
               {
            ?>
            <li><a href="login.php" >Login</a></li>
               
             <?php  }
                  else
                  {
             ?>
               <li><a href="logout.php">Logout</a></li>
               <?php
                  }
               ?>
			</ul>
			</div>
		</div>
	</nav>
<div class="clearfix"></div>