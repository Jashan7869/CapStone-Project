<?php
include("config.php");

$token = $_POST["stripeToken"];
$amount = "45";
$desc = "Appointment Fee";
$charge = \Stripe\Charge::create([
			'amount'=>str_replace(",","",$amount) * 100,
			'description'=>$desc,
			'currency'=>'usd',
			'source'=>$token,
			]);
if($charge){
	header("location:paysuccess.php");
}
?>