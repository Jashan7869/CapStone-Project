<?php
session_start();
if(!isset($_SESSION['userid']))
{
   header('location:login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Doctor List</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<?php include('header.php'); ?>
<div class="container-fluid">
<br>
<br>
	<h2 class="text-center text-primary">Doctor List</h2>

   <div class="col-md-2">
      <p><a href="appointmentlist.php" class="btn btn-primary btn-block commandStyling">Appointment List</a></p>
      <p><a href="doctorlist.php" class="btn btn-primary btn-block commandStyling">Doctor List</a></p>
      <p><a href="patientlist.php" class="btn btn-primary btn-block commandStyling">Patient List</a></p>
   </div>
   <div class="col-md-10">
   <br>
<p class="text-right"><input id="myInput" type="text" placeholder="Search.."></p>
<br>
   <?php
   $conn = mysqli_connect('localhost','root','','hospital');
   if(!$conn)
   {
      die('database not connected');
   }
   $cmd = "Select * from Doctor ";

   $result= mysqli_query($conn, $cmd);

   $num = mysqli_num_rows($result);
   if($num>0)
   {
   ?>
         <table class="table table-bordered">
            <tr>
               <th>Doctor ID</th>
               <th>Doctor User ID</th>
               <th>SpecialiZation</th>
                <th>Doctor Name</th>
               <th>Doctor Phone</th>
               <th>Doctor Email</th>
               <th>First Name</th>
               <th>Last Name</th>
               
            </tr>
             <tbody id="myTable">
            <?php
               while($row= mysqli_fetch_array($result))
               {
               ?>
                  <tr>
                     <td><?php echo $row['Doctor_ID']; ?></td>
                     <td><?php echo $row['Doctor_UserID']; ?></td>
                     <td><?php echo $row['Specialization']; ?></td>
                    
                     <td><?php echo $row['Doctor_Name']; ?></td>
                     <td><?php echo $row['Doctor_PhoneNO']; ?></td>
                     <td><?php echo $row['Doctor_EmailID']; ?></td>
                     <td><?php echo $row['F_Name']; ?></td>
                     <td><?php echo $row['L_Name']; ?></td>
                     
                     
                  </tr>
                
               <?php
               }  
            ?>
         </tbody>
         </table> 
   <?php
   }
   else
   {
      echo "No Doctor Found...";
   }

   ?> 
     </div>
</div>



<br>
<br>


<?php include('footer.php'); ?>
</body>
</html>