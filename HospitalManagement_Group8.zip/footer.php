<div class="clearfix"></div>
<div class="col-md-12 footer">
	<div class="container text-center">
	<p> 
		<a href="http://www.facebook.com" title="Facebook" target="_blank"><i class="fab fa-facebook fa-2x fa-fw"></i></a>
            <a href="http://www.instagram.com" title="Instagram" target="_blank"><i class="fab fa-instagram fa-2x fa-fw"></i></a>
            <a href="http://www.twitter.com" target="_blank" title="twitter"><i class="fab fa-twitter fa-2x fa-fw"></i></a>
            <a href="http://www.gmail.com" target="_blank" title="Gmail"><i class="fab fa-google fa-2x fa-fw"></i></a></p>
	



	<p class="links">
		 <a href="index.html">Home</a>
            <a href="services.php">Services</a>
            <a href="contact.php">Contact Us</a>
            <a href="about.php">About Us</a>
            <?php
               if(!isset($_SESSION['userid']))
               {
            ?>
            <a href="login.php" >Login</a>
               
             <?php  }
                  else
                  {
             ?>
               <a href="logout.php">Logout</a>
               <?php
                  }
               ?>
	</p>



		<p>Phone:+1(989)898989898</p>
		<p>Email:caretaker@gmail.com</p>

	<p class="text-center">&copy; All Rights Reserved</p>
	</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 <script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script> 