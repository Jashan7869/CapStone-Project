<?php
session_start();
if(!isset($_SESSION['userid']))
{
   header('location:login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Payments page</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

	<?php include('header.php'); ?>
<div class="container-fluid about">
	<h2 class="text-center text-primary">Pay Appointment Fee</h2>
   <hr>
   
   <div class="col-md-10">
      <h4 style="text-align:center;margin-left:20%">Balance: $45.00<h4>
	  <br>
      <form action="checkout-charge.php" method="post" style="margin-left:50%">
	  
       
        <!--<p><input type="text" name="cardnumber" placeholder="Card Number" required pattern="[0-9]{16}"></p>
		<p><input type="text" name="address" placeholder="Street Address" required pattern="[a-z, A-Z, 0-9]{3,}"></p>
		<p><input type="text" name="apt" placeholder="Apt, unit, suite" required pattern="[a-z, A-Z, 0-9]{3,}"></p>
		<p><input type="text" name="country" placeholder="Country" required pattern="[a-z, A-Z]{3,}"></p>
		<p><input type="text" name="city" placeholder="City" required pattern="[a-z, A-Z]{3,}"></p>
		<p><input type="text" name="state" placeholder="State" required pattern="[a-z, A-Z]{3,}"></p>
		<p><input type="text" name="zipcode" placeholder="Zip code" requiredpattern="[0-9]{3,}"></p>

       <p><input type="submit" class="btn btn-primary commandStyling" value="Pay Now"></p>-->
	   <div style="margin-left:10%">
	 <script 
	 src="https://checkout.stripe.com/checkout.js" class="stripe-button"
	 data-key="pk_test_51K1XfGHBVv0ZWAOhK9PRAPpyYg4RHourPSLBRnCaYFFdripc1tK3F1HAzvBMbSbat6PCwWRYY1tUHSRcjGoFapi900DDK1ihZd"
	 data-amount=<?php echo str_replace(",","","45") * 100 ?>
	 data-description="Appointment fees"
	 data-currency="usd"
	 data-locale="auto">
	 </script>
	 </div>
	 <br>
	   <p style="margin-left:8%"><a href="myappointments.php" class="button">Pay Later</a></p>
	   <br>
	   <br>
     
	 
	 </div>
	 </form>
	  </div>
</div>




<?php include('footer.php'); ?>
</body>
</html>