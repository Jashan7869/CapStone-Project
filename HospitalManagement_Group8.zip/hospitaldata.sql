-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 10, 2021 at 03:04 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10
use hospital;
INSERT INTO `doctor` (`Doctor_ID`, `Doctor_Name`, `Doctor_PhoneNO`, `Doctor_EmailID`,`F_Name`, `L_Name`, `Doctor_UserID`, `Doctor_Password`,`Specialization`) VALUES (1, 'Dr. Michelle Heintges', '9876546891', 'heintges@gmail.com','Michelle', 'Heintges','michelle','password1',' Ob/Gyn'),(2, 'Dr. Amy Sigman', '9866587891', 'sigman@gmail.com','Amy', 'Sigman','amy','password1',' Ob/Gyn');
INSERT INTO `patient` (`Patient_id`, `F_Name`,`L_Name`,`Appointment_ID`, `Patient_UserID`,`Patient_password`, `Phone_No`,`Patient_EmailID`) VALUES (1, 'Jon', 'Torrey', 1,'torrey','password1','987654322','torrey@gmail.com'),(2, 'John', 'Heerema', 1,'heerema','password1','987654322','heerema@gmail.com');
INSERT INTO `appointment` (`Doctor_ID`, `Patient_ID`,`Slot_No`,`Appointment_ID`, `Appointment_Date`) VALUES (1, 1, 1, 1,'10/01/2021'),(1, 2, 2, 2,'12/01/2021');
INSERT INTO `admin` (`password`,`username`) VALUES ('test', 'admin1'),('test','admin2');