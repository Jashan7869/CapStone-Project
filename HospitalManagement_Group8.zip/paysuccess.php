<?php
session_start();
if(!isset($_SESSION['userid']))
{
   header('location:login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Pay Success</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

	<?php include('header.php'); ?>
	<br>
	<br>
	<br>
	<br>
	<div style="text-align: center;">
<h2 >You have Successfully made the payment</h2>
<br>
	<br>
	<br>
	<br>
	<p><a href="myappointments.php" class="button">My Appointments</a></p>
	<p><a href="index.php" class="button">Home page</a></p>
	</div>
	<br>
	<br>
<?php include('footer.php'); ?>
</body>
</html>