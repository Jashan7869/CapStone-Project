<?php
session_start();
if(!isset($_SESSION['userid']))
{
   header('location:login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Appointment List</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<?php include('header.php'); ?>
<div class="container-fluid about">
	<h2 class="text-center text-primary">My Appointments</h2>
   <div class="col-md-2">
      <p><a href="myappointments.php" class="btn btn-primary btn-block commandStyling">My Appointments</a></p>
      <p><a href="book.php" class="btn btn-primary btn-block commandStyling">Book Appointment</a></p>
      
   </div>
   <div class="col-md-10 table-responsive">
      <p class="text-right"><input id="myInput" type="text" placeholder="Search.."></p>
	<?php
   $conn = mysqli_connect('localhost','root','','hospital');
   if(!$conn)
   {
   	die('database not connected');
   }
   $cmd = "Select * from appointment where Patient_ID='".$_SESSION['userid']."' ORDER BY Appointment_ID DESC";

   $result= mysqli_query($conn, $cmd);

   $num = mysqli_num_rows($result);
   if($num>0)
   {
   ?>
   		<table class="table table-bordered">
   			<tr>
   				<th>Appointment ID</th>
   				<th>Doctor Name</th>
   				<th>Patient ID</th>
   				<th>Slot No.</th>
   				<th>Appointment Date</th>
   				
   			</tr>
             <tbody id="myTable">
   			<?php
   				while($row= mysqli_fetch_array($result))
   				{
   				?>
   					<tr>
   						<td><?php echo $row['Appointment_ID']; ?></td>
   						<td><?php 
                      $cmd1 = "select Doctor_Name from doctor where Doctor_ID=".$row['Doctor_ID'];
                       $res1 = mysqli_query($conn, $cmd1);
                       $row1= mysqli_fetch_array($res1);
                     echo $row1['Doctor_Name']; 

                     ?></td>
   						<td><?php echo $row['Patient_ID']; ?></td>
   						<td><?php echo $row['Slot_No']; ?></td>
   						<td><?php echo $row['Appointment_Date']; ?></td>
   					</tr>
   				<?php
   				}	
   			?>
         </tbody>
   		</table>	
   <?php
   }
   else
   {
   	echo "No Appointments Found...";
   }

   ?>	
	  </div>
</div>




<?php include('footer.php'); ?>
</body>
</html>