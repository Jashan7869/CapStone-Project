<?php
session_start();
if(!isset($_SESSION['userid']))
{
   header('location:login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Appointment List</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

<?php include('header.php'); ?>
<div class="container-fluid">
<br>
<br>
<br>
	<h2 class="text-center text-primary">Appointment List</h2>
   <div class="col-md-2">
      <p><a href="appointmentlist.php" class="btn btn-primary btn-block commandStyling">Appointment List</a></p>
      <p><a href="doctorlist.php" class="btn btn-primary btn-block commandStyling">Doctor List</a></p>
      <p><a href="patientlist.php" class="btn btn-primary btn-block commandStyling">Patient List</a></p>
   </div>
   <br>
   <div class="col-md-10">
      <p class="text-right"><input id="myInput" type="text" placeholder="Search.."></p>
	  <br>
	<?php
   $conn = mysqli_connect('localhost','root','','hospital');
   if(!$conn)
   {
   	die('database not connected');
   }
  
   $cmd = "SELECT Appointment_ID,Doctor_Name,Slot_No,Appointment_Date,pa.F_Name,pa.L_Name from appointment ap JOIN doctor doc ON ap.Doctor_ID = doc.Doctor_ID JOIN patient pa ON pa.Patient_ID = ap.Patient_ID";

   $result= mysqli_query($conn, $cmd);

   $num = mysqli_num_rows($result);
   if($num>0)
   {
   ?>
   		<table class="table table-bordered">
   			<tr>
   				<th>Appointment ID</th>
   				<th>Doctor Name</th>
   				<th>Patient Name</th>
   				<th>Slot No.</th>
   				<th>Appointment Date</th>
   				
   			</tr>
             <tbody id="myTable">
   			<?php
   				while($row= mysqli_fetch_array($result))
   				{
					$pFullname = $row['F_Name']." ".$row['L_Name']
   				?>
   					<tr>
   						<td><?php echo $row['Appointment_ID']; ?></td>
   						<td><?php echo $row['Doctor_Name']; ?></td>
   						<td><?php echo $pFullname; ?></td>
   						<td><?php echo $row['Slot_No']; ?></td>
   						<td><?php echo $row['Appointment_Date']; ?></td>
   					</tr>
   				<?php
   				}	
   			?>
         </tbody>
   		</table>	
   <?php
   }
   else
   {
   	echo "No Appointments Found...";
   }

   ?>	
	  </div>
</div>



<br>
<br>
<br>
<?php include('footer.php'); ?>
</body>
</html>