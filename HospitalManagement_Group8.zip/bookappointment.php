<?php
session_start();
   $conn = mysqli_connect('localhost','root','','hospital');
   if(!$conn)
   {
   	die('database not connected');
   }


   $docid=$_POST['docid'];
   $pid  = $_SESSION['userid'];
   $slot  = $_POST['slot'];
   $date  = $_POST['date'];

   $str = "select * from appointment where Slot_No='".$slot."' AND Appointment_Date='".$date."'";
   $res = mysqli_query($conn, $str);
   $num = mysqli_num_rows($res);

   if($num>0)
   {

         header('location:book.php?error=1');
   }
    else
    {  
            $cmd = "insert into appointment(Doctor_ID, Patient_ID, Slot_No, Appointment_Date) values('".$docid."','".$pid."','".$slot."','".$date."')";

            if(mysqli_query($conn, $cmd))
            {
            	header('location:payment.php');
            }
            else
            {
            	echo mysqli_error($conn);
               }

}
?>