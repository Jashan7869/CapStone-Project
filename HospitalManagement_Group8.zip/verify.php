<?php

session_start();
   $conn = mysqli_connect('localhost','root','','hospital');
   if(!$conn)
   {
   	die('database not connected');
   }


   $logintype=$_POST['logintype'];
   $user  = $_POST['username'];
   $pass  = $_POST['password'];

   if($logintype=="Doctor")
   {
   	$cmd = "select Doctor_ID,Doctor_Password from doctor where Doctor_UserID='".$user."'";
   }
   else if($logintype=="Patient")
   {
   	$cmd = "select Patient_ID,Patient_password from patient where Patient_UserID='".$user."'";
   }
   else if($logintype=="Admin")
   { 
   	$cmd = "select Admin_ID from admin where username='".$user."' AND password='".$pass."'";
   }


			$_SESSION['logintype']=$logintype;
   $result = mysqli_query($conn, $cmd);
	
   $num = mysqli_num_rows($result);
   
   if($num==1)
   {
   	$row = mysqli_fetch_array($result);
            if($logintype=="Doctor")
         {
            $password=$row['Doctor_Password'];
			$verify = password_verify($pass, $password);
			if ($verify) {
			  $_SESSION['userid']=$row['Doctor_ID'];
			  header('location:index.php');
			} else {
			  header('location:login.php?error=101');
			}
         }
         else if($logintype=="Patient")
         {
		  $password=$row['Patient_password'];
		  $verify = password_verify($pass, $password);
		  if ($verify) {
			  $_SESSION['userid']=$row['Patient_ID'];
			  header('location:index.php');
			} else {
			  header('location:login.php?error=101');
			}
         }
         else if($logintype=="Admin")
         { 
           $_SESSION['userid']=$row['Admin_ID'];
           header('location:index.php');
         }

   }
   else
   {
   	header('location:login.php?error=101');
   }

?>