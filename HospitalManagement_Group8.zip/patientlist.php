<?php
session_start();
if(!isset($_SESSION['userid']))
{
   header('location:login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Patient List</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>


<?php include('header.php'); ?>
<div class="container-fluid">
<br>
   <h2 class="text-center text-primary">Patient List</h2>
   <div class="col-md-2">
      <p><a href="appointmentlist.php" class="btn btn-primary btn-block commandStyling">Appointment List</a></p>
      <p><a href="doctorlist.php" class="btn btn-primary btn-block commandStyling">Doctor List</a></p>
      <p><a href="patientlist.php" class="btn btn-primary btn-block commandStyling">Patient List</a></p>
   </div>
   <div class="col-md-10">
   <br>
      <p class="text-right"><input id="myInput" type="text" placeholder="Search.."></p>
	  <br>
   <?php
   $conn = mysqli_connect('localhost','root','','hospital');
   if(!$conn)
   {
      die('database not connected');
   }
   $cmd = "Select * from patient";

   $result= mysqli_query($conn, $cmd);

   $num = mysqli_num_rows($result);
   if($num>0)
   {
   ?>
         <table class="table table-bordered">
            <tr>
               <th>Patient ID</th>
               <th>Patient User ID</th>
               <th>First Name</th>
               <th>Last Name</th>
               <th>Patient Phone</th>
               <th>Patient Email</th>
               
            </tr>
            <tbody id="myTable">
            <?php
               while($row= mysqli_fetch_array($result))
               {
               ?>
                  <tr>
                     <td><?php echo $row['Patient_ID']; ?></td>
                     <td><?php echo $row['Patient_UserID']; ?></td>
                     <td><?php echo $row['F_Name']; ?></td>
                     <td><?php echo $row['L_Name']; ?></td>
                     <td><?php echo $row['Phone_No']; ?></td>
                     <td><?php echo $row['Patient_EmailID']; ?></td>
                  </tr>
                
               <?php
               }  
            ?>
         </tbody>
         </table> 
   <?php
   }
   else
   {
      echo "No Patient Found...";
   }

   ?> 
     </div>
</div>



<br>
<br>
<?php include('footer.php'); ?>

</body>
</html>