<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">

</head>
<body>

	<?php include('header.php'); 
	
	?>
<div class="col-md-12 banner">
	<div class="col-md-6 col-md-offset-3">
   <h1><b>WELCOME</b></h1>
	<h1><b>Making Health Care Better Together</b></h1>
	<h3>A dedicated group of board-certified doctors professionals in all the branches and 20 locations near you and your family </h3>
	
	<?php 
	if(isset($_SESSION['logintype'])) {
	$logintype = $_SESSION['logintype'];
            if($logintype=="Doctor")
         {?>
            <p><a href="appointments.php" class="button">My Appointments</a></p>
      <?php   }
 else if($logintype=="Patient") { ?>
			<p><a href="myappointments.php" class="button">My Appointments</a></p>
			<p><a href="book.php" class="button">Book Appointment</a></p>
	 
 <?php   }
 else if($logintype=="Admin") { ?>
	<p><a href="appointmentlist.php" class="button">Appointments List</a></p>
	<p><a href="doctorlist.php" class="button">Doctors List</a></p>
	<p><a href="patientlist.php" class="button">Patients List</a></p>
 <?php } 
	}?>
	
	</div>


</div>



 <div class="col-md-12  membershipBSection">

            <h1 class="text-center">Testimonials</h1>
            <h3 class="text-center">Explore What Our Clients Think of Us</h3>
<br>
         <div class="container">
            <div class="col-md-2">
            	 <img src="images/client1.jpg" alt="client 1 image">
            </div>
                <div class="col-md-4">
                   
                    <p><q>Such a great group! Organized, efficient and amazing!
                       <br>Everyone is so kind and willing to answer questions,<br>going above and beyond to put patients at ease.</q><br><br><strong><i>Larry Page.</i></strong></p>
                </div>

            <div class="col-md-2">
            	 <img src="images/client2.jpg" alt="client 1 image">
            </div>
                <div class="col-md-4">
                  
                    <p><q>So far my experience with TCT have been wonderful! <br>The staff and doctors are super nice, helpful, <br>and comforting through the whole process!</q><br><br><strong><i>John Doe.</i></strong>
                    </p>
                </div>

            </div>
        </div>
        </div>



<?php include('footer.php'); ?>
</body>
</html>