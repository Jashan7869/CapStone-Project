<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Services Page</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

	<?php include('header.php'); ?>
<div class="container about">
	<h2 class="text-center text-primary">Types of Services</h2>
		<hr>
		<div class="col-md-2">
				<img src="images/s1.png" class="img-responsive">
		</div>
		<div class="col-md-4">
		<p>DAN Women & Babies Program provides pre-conception, pregnancy, delivery & post-birth care, as well as gynecological care.</p>

		<p>Here you can find clinical resources and patient education information.</p>
		</div>
		
		<div class="col-md-2">
				<img src="images/s2.png" class="img-responsive">
		</div>
		<div class="col-md-4">
		<p>We are one of North America's leading programs for musculoskeletal care, education and research. As part of the largest trauma centre in the country, we focus on complex injuries that cannot be managed elsewhere.</p>
		</div>

		<div class="clearfix"></div>
		<div class="col-md-2">
				<img src="images/s3.jpg" class="img-responsive">
		</div>
		<div class="col-md-4">
			<p>We have a team of expert cardiac surgeons, cardiologists, vascular surgeons and cardiac anaesthetists that work together to find some of the world's most innovative ways to treat the heart and damaged blood vessels. </p>
		</div>

		<div class="col-md-2">
				<img src="images/s4.jpg" class="img-responsive">
		</div>
		<div class="col-md-4">
			<p>We are home to the first and largest trauma centre in Canada, and the country's largest adult burn centre. Our teams support many hospital areas, including cancer, bone and joint, and neurosurgery. </p>
		</div>
		
	
</div>




<?php include('footer.php'); ?>
</body>
</html>