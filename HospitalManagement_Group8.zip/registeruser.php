<?php
session_start();
   $conn = mysqli_connect('localhost','root','','hospital');
   if(!$conn)
   {
   	die('database not connected');
   }


   $logintype=$_POST['logintype'];
   $fname  = $_POST['fname'];
   $lname  = $_POST['lname'];
   $mob  = $_POST['mob'];
   $email  = $_POST['email'];
   $userid  = $_POST['username'];
   $pass  = $_POST['password'];
   $fullname = $fname . $lname;

   $hash = password_hash($pass, PASSWORD_DEFAULT); 
  
   if($logintype=="Doctor") {
   	$cmd = "insert into doctor (F_Name, L_Name, Doctor_UserID, Doctor_EmailID, Doctor_password,Doctor_Name,Doctor_PhoneNO) values('".$fname."','".$lname."','".$userid."','".$email."','".$hash."','".$fullname."','".$mob."')";
   }
    else if($logintype=="Patient")
   {
   	$cmd = "insert into patient (F_Name, L_Name, Patient_UserID, Patient_EmailID, Phone_No,Patient_password) values('".$fname."','".$lname."','".$userid."','".$email."', '".$mob."' ,'".$hash."')";
   }
  
   if(mysqli_query($conn, $cmd))
   {
   	echo "Successfully registered. Please login";
   	header('location:index.php');
   }
   else
   {
   	echo mysqli_error($conn);
   }

?>